# Canteen-Management-System-C-linked-list
This is a canteen management system in C lang. Linked lists and arrays have been used for this project

A menu of food items available has been listed.

A menu of choices (whether to add an item or delete, etc) has also been given.
